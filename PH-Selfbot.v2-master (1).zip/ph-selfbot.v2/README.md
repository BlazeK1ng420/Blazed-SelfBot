# Pornhub-selfbot.v2-release
Release version 2 for my discord selfbot

Basically has everything you need for a selfbot


## Notable Features

```python
- Snipe
- Editsnipe
- Message logger
- Mee6 auto level up
- Nitro sniper
- Giveaway sniper
- Slotbot sniper
- Image search
- Image manipulation
- Massreact
- Copycat
- 24/7 yui kiss/hug
- Many more
```

## Previews

![Preview1](https://syz.s-ul.eu/ptKW8QQT)
![Preview2](https://syz.s-ul.eu/RBbsUcrA)


## Installation
**Clone the source or [Download the repo](https://gitdab.com/12/PH-Selfbot.v2.git)** Open **Install.bat**